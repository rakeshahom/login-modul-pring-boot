package com.genius.AI_code.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.genius.AI_code.Model.Login;
import com.genius.AI_code.Model.Roles;
import com.genius.AI_code.Repository.LoginRepository;
import com.genius.AI_code.Repository.RoleRepository;
import com.genius.AI_code.Service.EmailService;
import com.genius.AI_code.Service.LoginService;

@Controller
public class LoginController {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private LoginService loginService;
	@Autowired
	private EmailService emailService;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	LoginRepository loginRepository;

	
	@GetMapping("/verify_mail")
	public String getOtp() {
		return "mailverify";
	}

//	@PostMapping("/verify_mail/verify")
//	@ResponseBody
//	public String matchOtp(@RequestParam String verificationcode) {
//		if (verificationcode == null) {
//			return "error";
//		}
//		
//		Login login = new Login();
//		login.setStatus(true);
//		loginRepository.save(login);
//		return "successfullupdate";
//
//	}

	@GetMapping("/signup")
	public String register(Model model) {
		model.addAttribute("title", "Sign-up");
		model.addAttribute("user", new Login());
		return "signup";
	}

	@GetMapping("/login")
	public String signin(Model model) {
		model.addAttribute("title", "Sign-in");
		return "signin";
	}

	@PostMapping("/signup/add")
	public String saveUser(@ModelAttribute("user") Login userlogin, Model model, HttpServletRequest request,HttpSession session)
			throws ServletException {
		Random rnd = new Random();
		int number = rnd.nextInt(999999);
		String otp = String.format("%06d", number);

		String subject = "EDUSOL verification code";
		String message = "hi " + userlogin.getName() + " we received to request create account in EDUSOL  " + otp;
		String password = userlogin.getPassword();
		userlogin.setPassword(bCryptPasswordEncoder.encode(password));
		List<Roles> role = new ArrayList<>();
		role.add(roleRepository.getById(2));
		userlogin.setRoles(role);
		loginRepository.save(userlogin);

		request.login(userlogin.getUsername(), password);

		System.out.println("this is my otp-:" + otp + userlogin.getEmail());
		boolean result = this.emailService.emailSend(subject, message, userlogin.getEmail());

		if (result) {
			session.setAttribute("otp", otp);
			session.setAttribute("email", userlogin.getEmail());
			return "redirect:/verify_mail";
		} else {
			model.addAttribute("msg", "something went wrong.....");
			return "redirect:/signup";
		}
	}

}
