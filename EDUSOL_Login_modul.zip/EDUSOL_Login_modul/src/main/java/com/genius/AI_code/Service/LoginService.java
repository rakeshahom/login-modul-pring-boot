package com.genius.AI_code.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.Repository.LoginRepository;

@Service
public class LoginService {
@Autowired
LoginRepository loginRepository;

	
	public Object getUserById(int id) {
		// TODO Auto-generated method stub
		return loginRepository.findById(id);
	}

}
