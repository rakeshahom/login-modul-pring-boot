package com.genius.AI_code.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.genius.AI_code.Model.Login;
import com.genius.AI_code.Repository.LoginRepository;

public class CustomUserDetailsService implements UserDetailsService {
	@Autowired
	private LoginRepository loginRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		try {
			Login login = loginRepository.findUserByUsername(username);
			if (login != null) {
				return new CustomUserDetails(login);
			} else {
				throw new UsernameNotFoundException("user not Found...");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
